<template>
  <div id="app" class="w-screen h-screen overflow-hidden bg-black">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {}
</script>

<style>
  #app {
    font-family: 'Dancing Script', cursive;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
</style>
